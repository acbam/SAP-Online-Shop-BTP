sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast"
], function (Controller, MessageToast) {
    "use strict";

    return Controller.extend("sap.ui.demo.controller.App", {
        onNavToMain: function () {
            this.getOwnerComponent().getRouter().navTo("Main");
        },

        onNavToCart: function () {
            this.getOwnerComponent().getRouter().navTo("Cart");
        },

        onNavBack: function () {
            const oHistory = sap.ui.core.routing.History.getInstance();
            const sPreviousHash = oHistory.getPreviousHash();
        
            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("main", {}, true);
            }
        },

        onLoginPress: async function () {
            var oDialog = this.getView().byId("loginDialog");
            oDialog.open();
        },

        onLoginCancel: function () {
            this.getView().byId("loginDialog").close();
        },

        onLoginSubmit: function () {
             var oUsername = this.getView().byId("username");
             var oPassword = this.getView().byId("password");

             const oActionODataContextBinding = this.getView().getModel("authentication").bindContext("/login(...)");
             oActionODataContextBinding.setParameter("username", oUsername.getValue());
             oActionODataContextBinding.setParameter("password", oPassword.getValue());
             oActionODataContextBinding.execute().then(
                function() {
                    var authResult = oActionODataContextBinding.getBoundContext().getObject().value;
                    if (authResult){
                        MessageToast.show("Logged in successfully");
                        oUsername.setValue("");
                        oPassword.setValue("");
                        this.onLoginCancel();
                    }
                    else { MessageToast.show("Logged in failed"); }
                }.bind(this)
             );
        }
    });
});